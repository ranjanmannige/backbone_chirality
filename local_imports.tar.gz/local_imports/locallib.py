# GLOBAL IMPORTS:
import os, sys, copy, math
import matplotlib.pyplot as plt                       # For utilizing colormap interpolation 
import numpy as np
import Bio.PDB # Biopython's PDB module
from Bio import PDB
import sys,copy,os,re
import numpy as np
import matplotlib.pyplot as plt                       # For utilizing colormap interpolation 
from matplotlib.colors import LinearSegmentedColormap # For making your own colormaps
#
# LOCAL IMPORTS
import Geometry, PeptideBuilder

# ===================================================================================
# SETTING UP SOME COLORMAPS
# 
# THE NEW COLORMAPS ARE:
# cmap_chirality          = plt.get_cmap('chirality')
# cmap_chirality_r        = plt.get_cmap('chirality_r')
# cmap_chirality_signed   = plt.get_cmap('chirality_signed')
# cmap_chirality_signed_r = plt.get_cmap('chirality_signed_r')
# cmap_ss                 = plt.get_cmap('ss')
# cmap_ss_signed          = plt.get_cmap('ss_signed')
# YOU MAY OBTAIN SUCH CMAPS VIA EITHER SIDE OF THE EQUATION. E,g, after importing rnumber
# "rnumber.cmap_ss" and "plt.get_cmap('ss')" return the same CMAP, as do
# "rnumber.cmap_chirality_signed_r" and "plt.get_cmap('chirality_signed_r')".

COLORSWITCH = 0.5  #45 # THIS IS THE POINT, FOR THE CHIRALITY (RED/BLUE) AND SIGNED
                   # AND THE SIGNED CHIRALITY (RED/BLUE/YELLOW/BLACK) COLOR SCHEMES, 
                   # WHERE THE SWITCH IN COLOR HAPPENS (NAIVELY 0.5, BUT BETA SHEETS 
                   # SPILL TO THE "D" PORTION OF THE PLOT, SO THE VALUE OF 0.45 MAY 
                   # BE MORE APPROPRIATE).

# First, some definitions:
# DEFINING COLORS BY CHIRALITY:
# c stands for color, bc stands for background color             
             #    when R ranges from   [-1,1]  ("Signed R")     [0,1] (Traditional R)
             #                         ------------             -----------
c1 = [0,0,0] # black                   | \_ c4  / |             |\_    c4 |
c2 = [1,1,0] # yellow                  |   \_ /   |             |  \_     |
c3 = [1,0,0] # red                 psi |c3  /\_c2 |         psi |    \_   |
c4 = [0,0,1] # blue                    |  /    \_ |             |      \_ |
bc = [1,1,1] # background (white)      |/  c1    \|             |c3      \|
             #                         ------------             -----------
             #                             phi                      phi

# DEFINING POSITIONS AND COLORS BY SECONDARY STRUCTURE:
# POSITIONS
helix_start = 0.31 # the start of the helical region (all assuming R in [0,1])
helix_end   = 0.39 # the end of the helical region
sheet_start = 0.45 # the start of the sheet region
sheet_end   = 0.62 # the end of the sheet region
polyproline_end = 0.66 # the end of the polyprolineII region 
                       # (the start is in the middle of the the sheet region, so it can't be shown
                       # so it just begins after the sheet region ends)
# COLORS
helixR      = (1,0,0)
sheet       = (0,0,1)
polyproline = (0,1,1)

# ----------------
# NEW COLOR SCHEME: color by backbone twist (expected range: R=[0,1])
# ----------------
# This lets you later on get the cmap by name 'TwoColor': cmap = plt.get_cmap('TwoColor')
# POSITION: 0        COLORSWITCH         1
#    COLOR: | white - red | blue - white |
cdict = {
#                         white  white                  red    blue          white  white
	'red':   ((0.00,  bc[0], bc[0]), (COLORSWITCH,  c3[0], c4[0]), (1.0, bc[0], bc[0])), 
	'green': ((0.00,  bc[1], bc[1]), (COLORSWITCH,  c3[1], c4[1]), (1.0, bc[1], bc[1])),
	'blue':  ((0.00,  bc[2], bc[2]), (COLORSWITCH,  c3[2], c4[2]), (1.0, bc[2], bc[2])) 
}
cmap_chirality = LinearSegmentedColormap('chirality', cdict)
plt.register_cmap(cmap=cmap_chirality)
# ----------------
# NEW COLOR SCHEME: color by backbone twist, variant (expected range: R=[0,1])
# ----------------
# This lets you later on get the cmap by name 'TwoColorInverted': cmap = plt.get_cmap('TwoColorInverted')
# POSITION: 0              0.25             0.5           0.75            1
#    COLOR: | white - black | yellow - white | white - red | blue - white |
cdict = {
#                         red    red                    white  white         blue   blue
	'red':   ((0.00,  c3[0], c3[0]), (COLORSWITCH,  bc[0], bc[0]), (1.0, c4[0], c4[0])), 
	'green': ((0.00,  c3[1], c3[1]), (COLORSWITCH,  bc[1], bc[1]), (1.0, c4[1], c4[1])),
	'blue':  ((0.00,  c3[2], c3[2]), (COLORSWITCH,  bc[2], bc[2]), (1.0, c4[2], c4[2])) 
}
cmap_chirality_r = LinearSegmentedColormap('chirality_r', cdict)
plt.register_cmap(cmap=cmap_chirality_r)
# ----------------
# NEW COLOR SCHEME: color by backbone twist (expected range: R=[-1,1])
# ----------------
# This lets you later on get the cmap by name 'FourColor': cmap = plt.get_cmap('FourColor')
# POSITION: 0              0.25             0.5           0.75            1
#    COLOR: | white - black | yellow - white | white - red | blue - white |
cdict = {
#                         white  white           yellow black        white  white             red    blue          white  white
	'red':   ((0.00,  bc[0], bc[0]), (0.25,  c1[0], c2[0]), (0.50, bc[0], bc[0]), (0.75,  c3[0], c4[0]), (1.0, bc[0], bc[0])), 
	'green': ((0.00,  bc[1], bc[1]), (0.25,  c1[1], c2[1]), (0.50, bc[1], bc[1]), (0.75,  c3[1], c4[1]), (1.0, bc[1], bc[1])),
	'blue':  ((0.00,  bc[2], bc[2]), (0.25,  c1[2], c2[2]), (0.50, bc[2], bc[2]), (0.75,  c3[2], c4[2]), (1.0, bc[2], bc[2])) 
}
cmap_chirality_signed = LinearSegmentedColormap('chirality_signed', cdict)
plt.register_cmap(cmap=cmap_chirality_signed)
# ----------------
# NEW COLOR SCHEME: color by backbone twist, variant (expected range: R=[-1,1])
# ----------------
# This lets you later on get the cmap by name 'FourColorInverted': cmap = plt.get_cmap('FourColorInverted')
# POSITION: 0              0.25             0.5           0.75            1
#    COLOR: | black - white | white - yellow | red - white | white - blue |
cdict = {
#                         yellow yellow          white  white          black  red             white  white         blue   blue
	'red':   ((0.00,  c1[0], c1[0]), (0.25,  bc[0], bc[0]), (0.50, c2[0], c3[0]), (0.75,  bc[0], bc[0]), (1.0, c4[0], c4[0])), 
	'green': ((0.00,  c1[1], c1[1]), (0.25,  bc[1], bc[1]), (0.50, c2[1], c3[1]), (0.75,  bc[1], bc[1]), (1.0, c4[1], c4[1])),
	'blue':  ((0.00,  c1[2], c1[2]), (0.25,  bc[2], bc[2]), (0.50, c2[2], c3[2]), (0.75,  bc[2], bc[2]), (1.0, c4[2], c4[2])) 
}
cmap_chirality_signed_r = LinearSegmentedColormap('chirality_signed_r', cdict)
plt.register_cmap(cmap=cmap_chirality_signed_r)
# -------------------------
# NEW COLOR SCHEME: secondary structure (expected range: R=[0,1])
# ----------------
# This lets you later on get the cmap by name 'SecondaryStructure': cmap = plt.get_cmap('SecondaryStructure')
# POSITION: 0          helix_start       helix_end       sheet_start     sheet_end             polyproline_end            1
#    COLOR: | white - white | helixR - helixR | white - white | sheet - sheet | polyproline - polyproline | white - white |
cdict = {  
           'red': ((0.00,  bc[0], bc[0]), (helix_start,  bc[0], helixR[0]), (helix_end,  helixR[0], bc[0]), (sheet_start,  bc[0], sheet[0]), (sheet_end,  sheet[0], polyproline[0]), (polyproline_end, polyproline[0], bc[0]), (1, bc[0],bc[0])), 
         'green': ((0.00,  bc[1], bc[1]), (helix_start,  bc[1], helixR[1]), (helix_end,  helixR[1], bc[1]), (sheet_start,  bc[1], sheet[1]), (sheet_end,  sheet[1], polyproline[1]), (polyproline_end, polyproline[1], bc[1]), (1, bc[1],bc[1])),
          'blue': ((0.00,  bc[2], bc[2]), (helix_start,  bc[2], helixR[2]), (helix_end,  helixR[2], bc[2]), (sheet_start,  bc[2], sheet[2]), (sheet_end,  sheet[2], polyproline[2]), (polyproline_end, polyproline[2], bc[2]), (1, bc[2],bc[2]))
        }
cmap_ss = LinearSegmentedColormap('ss', cdict)
plt.register_cmap(cmap=cmap_ss)
# ----------------
# NEW COLOR SCHEME: color by secondary structure (expected range: R=[-1,1])
# ----------------
# POSITION (MIRRORRED AROUND 0): 0          helix_start       helix_end       sheet_start     sheet_end             polyproline_end            1
#                         COLOR: | white - white | helixR - helixR | white - white | sheet - sheet | polyproline - polyproline | white - white |
cdict = {  
           'red': [[-1,  bc[0], bc[0]], [polyproline_end*-1, bc[0],polyproline[0]], [sheet_end*-1,  polyproline[0],sheet[0]], [sheet_start*-1,  sheet[0], bc[0]], [helix_end*-1, bc[0],helixR[0]], [helix_start*-1, helixR[0],bc[0]], [helix_start,  bc[0], helixR[0]], [helix_end,  helixR[0], bc[0]], [sheet_start,  bc[0], sheet[0]], [sheet_end,  sheet[0], polyproline[0]], [polyproline_end, polyproline[0], bc[0]], [1, bc[0],bc[0]]],
         'green': [[-1,  bc[1], bc[1]], [polyproline_end*-1, bc[1],polyproline[1]], [sheet_end*-1,  polyproline[1],sheet[1]], [sheet_start*-1,  sheet[1], bc[1]], [helix_end*-1, bc[1],helixR[1]], [helix_start*-1, helixR[1],bc[1]], [helix_start,  bc[1], helixR[1]], [helix_end,  helixR[1], bc[1]], [sheet_start,  bc[1], sheet[1]], [sheet_end,  sheet[1], polyproline[1]], [polyproline_end, polyproline[1], bc[1]], [1, bc[1],bc[1]]], 
          'blue': [[-1,  bc[2], bc[2]], [polyproline_end*-1, bc[2],polyproline[2]], [sheet_end*-1,  polyproline[2],sheet[2]], [sheet_start*-1,  sheet[2], bc[2]], [helix_end*-1, bc[2],helixR[2]], [helix_start*-1, helixR[2],bc[2]], [helix_start,  bc[2], helixR[2]], [helix_end,  helixR[2], bc[2]], [sheet_start,  bc[2], sheet[2]], [sheet_end,  sheet[2], polyproline[2]], [polyproline_end, polyproline[2], bc[2]], [1, bc[2],bc[2]]]  
        } 
# this cdict is not normalized from 0 to 1, which is required for the line following the "for" loop.
minpos = False
maxpos = False
for color in  cdict.keys():
	for i in range(len(cdict[color])):
		if minpos == False:
			minpos = cdict[color][i][0]
		if maxpos == False:
			maxpos = cdict[color][i][0]
		if minpos > cdict[color][i][0]:
			minpos = cdict[color][i][0]
		if maxpos < cdict[color][i][0]:
			maxpos = cdict[color][i][0]
for color in  cdict.keys():
	for i in range(len(cdict[color])):
		cdict[color][i][0] = float(cdict[color][i][0]-minpos)/(maxpos-minpos)
cmap_ss_signed = LinearSegmentedColormap('ss_signed', cdict)
plt.register_cmap(cmap=cmap_ss_signed)

def calculate_rmsd(ref_structure,sample_structure,atoms_to_be_aligned1=[],atoms_to_be_aligned2=[]):
	ref_model = ref_structure[0]
	sample_model = sample_structure[0]
	
	#ref_structure = pdb_parser.get_structure("reference", "1D3Z.pdb")
	#sample_structure = pdb_parser.get_structure("samle", "1UBQ.pdb")
	
	# Make a list of the atoms (in the structures) you wish to align.
	# In this case we use CA atoms whose index is in the specified range
	ref_atoms = []
	sample_atoms = []
	
	align_all = 0
	
	if not len(atoms_to_be_aligned1):
		align_all = 1
	
	# Iterate of all chains in the model in order to find all residues
	for ref_chain in ref_model:
		# Iterate of all residues in each model in order to find proper atoms
		for ref_res in ref_chain:
			# Check if residue number ( .get_id() ) is in the list
			if align_all or ref_res.get_id()[1] in atoms_to_be_aligned1:
				# Append CA atom to list
				ref_atoms.append(ref_res['CA'])
				ref_atoms.append(ref_res['N'])
				ref_atoms.append(ref_res['C'])
	
	# Do the same for the sample structure
	for sample_chain in sample_model:
		for sample_res in sample_chain:
			if align_all or sample_res.get_id()[1] in atoms_to_be_aligned2:
				sample_atoms.append(sample_res['CA'])
				sample_atoms.append(sample_res['N'])
				sample_atoms.append(sample_res['C'])	
	# Now we initiate the superimposer:
	super_imposer = PDB.Superimposer() # "PDB" was "Bio.PDB"
	super_imposer.set_atoms(ref_atoms, sample_atoms)
	super_imposer.apply(sample_model.get_atoms())
	
	return super_imposer.rms,sample_structure

def calculate_handedness1(ref_structure,atoms_to_be_used=[]):
	ref_model = ref_structure[0]
	#
	ref_atomsCA = []
	# Iterate of all chains in the model in order to find all residues
	for ref_chain in ref_model:
		# Iterate of all residues in each model in order to find proper atoms
		for ref_res in ref_chain:
			# Check if residue number ( .get_id() ) is in the list
			use_residue = 0
			if not len(atoms_to_be_used):
				use_residue = 1
			else:
				if ref_res.get_id()[1] in atoms_to_be_used:
					use_residue = 1
			if use_residue:
				
				ref_atomsCA.append(ref_res['CA'].get_coord())
	
	orientations = []
	if 1:
		for resid in range(len(ref_atomsCA)):
			if resid > 0 and resid+3 < len(ref_atomsCA):
				CAm= ref_atomsCA[resid-1]
				CA = ref_atomsCA[resid]
				CAp= ref_atomsCA[resid+1]
				CApp= ref_atomsCA[resid+2]
				
				atoms     = [ CAm , CA , CAp , CApp ]
				
				r1 = atoms[0]
				r2 = atoms[1]
				r3 = atoms[2]
				r4 = atoms[3]
				
				v1m  = r2 - r1
				v1   = r3 - r2
				v1p  = r4 - r3
				
				# The denominator could be just np.linalg.norm(v1)**3 IF backbone omegas are either all cis or trans
				chirality = np.dot(np.cross(v1m,v1),v1p)/float(np.linalg.norm(v1m)*np.linalg.norm(v1)*np.linalg.norm(v1p))
				
				if not math.isnan(chirality):
					orientations.append(chirality)
		final_chirality = np.average(orientations)
	return final_chirality

def calculate_handedness2(ref_structure,atoms_to_be_used=[]):
	ref_model = ref_structure[0]
	#
	ref_atomsCA = []
	ref_atomsC = []
	ref_atomsN = []
	ref_atomsO = []
	# Iterate of all chains in the model in order to find all residues
	for ref_chain in ref_model:
		# Iterate of all residues in each model in order to find proper atoms
		for ref_res in ref_chain:
			# Check if residue number ( .get_id() ) is in the list
			use_residue = 0
			if not len(atoms_to_be_used):
				use_residue = 1
			else:
				if ref_res.get_id()[1] in atoms_to_be_used:
					use_residue = 1
			if use_residue:
				ref_atomsCA.append(ref_res['CA'].get_coord())
	
	
	orientations = []
	if 1:
		for resid in range(len(ref_atomsCA)):
			if resid > 0 and resid+3 < len(ref_atomsCA):
				CAm= ref_atomsCA[resid-1]
				CA = ref_atomsCA[resid]
				CAp= ref_atomsCA[resid+1]
				CApp= ref_atomsCA[resid+2]
				
				#1. First we get the a normal to the triangle
				atoms     = [ CAm , CA , CAp , CApp ]
				
				r1 = atoms[0]
				r2 = atoms[1]
				r3 = atoms[2]
				r4 = atoms[3]
				
				v1m  = r2 - r1
				v1   = r3 - r2
				v1p  = r4 - r3
				
				v1crossv1p = np.cross(v1,v1p)
				chirality = np.arctan2(np.dot(np.linalg.norm(v1)*v1m, v1crossv1p),
							np.dot(      np.cross(v1m,v1), v1crossv1p))
				
				if not math.isnan(chirality):
					orientations.append(chirality)
		final_chirality = np.average(orientations)/np.pi
	return final_chirality

def calculate_handedness3(ref_structure,atoms_to_be_used=[]):
	ref_model = ref_structure[0]
	#
	ref_atomsCA = []
	# Iterate of all chains in the model in order to find all residues
	for ref_chain in ref_model:
		# Iterate of all residues in each model in order to find proper atoms
		for ref_res in ref_chain:
			# Check if residue number ( .get_id() ) is in the list
			use_residue = 0
			if not len(atoms_to_be_used):
				use_residue = 1
			else:
				if ref_res.get_id()[1] in atoms_to_be_used:
					use_residue = 1
			if use_residue:
				ref_atomsCA.append(ref_res['CA'].get_coord())
	
	orientations = []
	if 1:
		n = 2.0
		m = 1.0
		four_prime = 4.0*3.0*2.0
		N_to_the_fourth = float(len(ref_atomsCA)**4.0)
		
		range_len_ref_atomsCA = range(len(ref_atomsCA))
		
		for i in range_len_ref_atomsCA:
			for j in range_len_ref_atomsCA:
				rij      = ref_atomsCA[i]-ref_atomsCA[j]
				rij_norm = np.linalg.norm(rij)
				for k in range_len_ref_atomsCA:
					rjk      = ref_atomsCA[j]-ref_atomsCA[k]
					rjk_norm = np.linalg.norm(rjk)
					for l in range_len_ref_atomsCA:
						if len(set([i,j,k,l])) == 4:
							rkl      = ref_atomsCA[k]-ref_atomsCA[l]
							rkl_norm = np.linalg.norm(rkl)
							ril      = ref_atomsCA[i]-ref_atomsCA[l]
							ril_norm = np.linalg.norm(ril)
							
							G0 = float(np.dot(np.cross(rij,rkl),ril)*np.dot(rij,rjk)*np.dot(rjk,rkl))/(3.0*((rij_norm*rjk_norm*rkl_norm)**n)*ril_norm**m)
							G0S = four_prime*G0/N_to_the_fourth
							orientations.append(G0S)
		final_chirality = np.sum(orientations)
	return final_chirality

def draw_histogram(data, bins=20):
	from scipy.stats import gaussian_kde
	
	a,b = np.histogram(data,bins=bins)
	hisX = []
	hisY = []
	plt.clf()
	for i in range(len(a)):
		hisx = float(b[i]+b[i+1])/2.0
		hisy = float(a[i])/sum(a)
		hisX.append(hisx)
		hisY.append(hisy)
	plt.plot(hisX,hisY)
	
	'''
	#bandwidth=.1
	data = np.array(data)
	hisX = np.arange(min(data),max(data)+0.001,float(max(data)-min(data))/1000.)
	kde = gaussian_kde(data)#, bw_method=bandwidth)# / data.std(ddof=1))
	kdepdf = kde.evaluate(hisX)
	plt.plot(hisX,kdepdf)
	
	# finding the maxima:
	maxima = []
	
	previousY = kdepdf[0]
	if kdepdf[1] < kdepdf[0]:
		maxima.append(hisX[0])
		
	for i in range(1,len(hisX)-1):
		if kdepdf[i-1] < kdepdf[i] and kdepdf[i+1] < kdepdf[i]:
			maxima.append(hisX[i])
	
	if kdepdf[-1] > kdepdf[-2]:
		maxima.append(hisX[-1])
	
	for m in maxima:
		plt.plot([m,m],[min(kdepdf),max(kdepdf)])
	'''
	plt.show()
	return 1


# important if you want to take our XYZ data and use it to create images using MATPLOTLIB
def xyz_to_image(X,Y,Z):
	# Making a list of the grid spacings in each dimension
	xset = sorted(set(X))
	yset = sorted(set(Y))
	
	# Getting the step sizes per dimension (assumption: equally spaced grid data)
	xstep = 1.0
	if len(xset) > 1: xstep = float(xset[1])-float(xset[0])
	ystep = 1.0
	if len(yset) > 1: ystep = float(yset[1])-float(yset[0])
	
	'''
	For a 4 x 2 image (say, with gridpoints at x = [1,2,3,4], y = [1,2]), we need to 
	be describing the *boundaries* at which each "square" lies. I.e., we need to 
	be describing boundaries at x_boundaries = [0.5,1.5,2.5,3.5,4.5] and 
	y_boundaries = [0.5,1.5,2.5]. Pictorally:
	2.5 .-----.-----.-----.-----.-----.
	    |     |     |     |     |     |
	    |(0,1)|(1,1)|(2,1)|(3,1)|(4,1)|
	    |     |     |     |     |     |
	1.5 .-----.-----.-----.-----.-----.
	    |     |     |     |     |     |
	    |(0,0)|(1,0)|(2,0)|(3,0)|(4,0)|
	    |     |     |     |     |     |
	0.5 .-----.-----.-----.-----.-----.
	   0.5   1.5   2.5   3.5   4.5   5.5
	'''

	xset_boundaries = np.append(xset,[xset[-1]+xstep]) - xstep/2
	yset_boundaries = np.append(yset,[yset[-1]+ystep]) - ystep/2
	
	imagex, imagey = np.meshgrid(xset_boundaries, yset_boundaries)
	
	# Filling and populating the color component (imagez)
	imagez = np.zeros((len(yset)  ,len(xset)  ))
	for x,y,z in zip(X,Y,Z):
		xi = xset.index(x)
		yi = yset.index(y)
		imagez[yi][xi] = z
	
	return imagex,imagey,imagez

# DRAWS POSTSCRIPT/EPS FILES USING INFORMATION IN Xoriginal, Yoriginal, Zoriginal
def make2Dfigure(Xoriginal,Yoriginal,Zoriginal,fn=None,cmap=plt.get_cmap('gray_r'),xscaling=2.0,
		 xlim=[],ylim=[],zlim=[],xtitle=None,ytitle=None,xticks=None,yticks=None,
		 horizontallines=None,verticallines=None,title=None,signed=-1,show=0,start_fresh=1,colorbar=0):
	#sns.set_style('ticks')
	
	start_fresh=0
	
	# Making sure that we do not modify the original XYZ
	X = copy.deepcopy(Xoriginal)
	Y = copy.deepcopy(Yoriginal)
	Z = copy.deepcopy(Zoriginal)
	
	if 1: # PREPROCESSING
		# FIRST WE FIND AND THEN DELETE ALL SETS OF VALUES THAT FALL 
		# OUTSIDE OF xlim or ylim
		deleteindices = []
		if len(xlim):
			for i in range(len(X)):
				if X[i] < xlim[0] or X[i] > xlim[1]:
					deleteindices.append(i)
		if len(ylim):
			for i in range(len(Y)):
				if Y[i] < ylim[0] or Y[i] > ylim[1]:
					deleteindices.append(i)
		deleteindices = sorted(list(set(deleteindices)))
		deleteindices.reverse()
		if len(deleteindices):
			for i in deleteindices:
				del X[i]
				del Y[i]
				del Z[i]
		
		# IF Z VALUES ARE LARGER OR SMALLER THAN THE zmin ALLOWS, THEN WE JUST 
		# RESET THOSE VALUES TO THE BORDERS
		if len(zlim):
			zmin = sorted(zlim)[0]
			zmax = sorted(zlim)[-1]
			for i in range(len(Z)):
				if Z[i] < zmin:
					Z[i] = zmin
				elif Z[i] > zmax:
					Z[i] = zmax
	
	# Getting the sorted and non-redundant values for X
	Xsorted = sorted(set(X))
	Ysorted = sorted(set(Y))
	
	# Working on setting up the dimensions of the drawing's frame 
	pageMinY = 2.5  # Arbitrary values
	pageMaxY = 14.5 #16.0 # Arbitrary values
	pageMinX = 3.0
	pageMaxX = pageMinX + float(pageMaxY-pageMinY)*xscaling
	
	xmin = Xsorted[0]
	xmax = Xsorted[-1]
	ymin = Ysorted[0]
	ymax = Ysorted[-1]
	
	if xlim is not None:
		if len(xlim) == 2 and xlim[0]<xlim[-1]:
			xmin=xlim[0]
			xmax=xlim[-1]
	if ylim is not None:
		if len(ylim) == 2 and ylim[0]<ylim[-1]:
			ymin=ylim[0]
			ymax=ylim[-1]
	
	zmin = round(sorted(Z)[0],2)
	zmax = round(sorted(Z)[-1],2)
	if zlim is not None: # this trumps all before
		if len(zlim) == 2 and zlim[0]<zlim[-1]:
			zmin = zlim[0]
			zmax = zlim[1]
	
	# THE MATPLOTLIB CODE
	if start_fresh:
		plt.clf() 
	
	#TO SEE THE OTHER KEYS TO PLAY WITH, USE: 'plt.rcParams.keys()'
	plt.rcParams['axes.linewidth'] = 1
	#plt.rcParams['axes.edgecolor'] = "r"
	
	imagex,imagey,imagez = xyz_to_image(X,Y,Z)
	xset = sorted(set(imagex.flatten()))
	yset = sorted(set(imagey.flatten()))
	extent = [xset[0], xset[-1], yset[0], yset[-1]]
	
	plt.pcolor(imagex,imagey,imagez, cmap=cmap, vmin=zmin,vmax=zmax)
	
	if xticks is not None:
		plt.xticks(xticks)
	if yticks is not None:
		plt.yticks(yticks)
	
	plt.axis(extent)
	
	if xtitle is not None: plt.xlabel(xtitle)
	if ytitle is not None: plt.ylabel(ytitle)
	if title is not None:  
		t = plt.title(title)
		t.set_y(1.03) # Shifting the title up a little
	
	# e.g. of horizontallines: None or [100,10] (would draw vertical lines at x=100 and x=10)
	#horizontallines = [0,1,2]
	if horizontallines is not None:
		for y in horizontallines:
			if yset[0] <= y and y <= yset[-1]:
				y = float(y)
				lineX = []
				lineY = []
				for x in [xset[0],xset[-1]]:
					lineX.append(x)
					lineY.append(y)
				# draw line
				plt.plot(lineX,lineY, 'k-')
	
	# e.g. of verticallines: None or [100,10] (would draw vertical lines at x=100 and x=10)
	#verticallines = [0,1,2]
	if verticallines is not None:
		for x in verticallines:
			if xset[0] <= x and x <= xset[-1]:
				x = float(x)
				lineX = []
				lineY = []
				for y in [yset[0],yset[-1]]:
					lineX.append(x)
					lineY.append(y)
				# draw line
				plt.plot(lineX,lineY, 'k-')
	
	# Setting the user-defined aspect ratio:
	plt.axes().set_aspect(abs((extent[1]-extent[0])/(extent[3]-extent[2]))/xscaling)
	
	if colorbar:
		plt.colorbar()
	
	if fn:
		filenames = []
		if isinstance(fn, str):
			filenames.append(fn)
		else:
			filenames = fn
		for fn in filenames:
			plt.savefig(fn,dpi=170,bbox_inches="tight")
	if show:
		plt.show()
	return 1

def open_file(fn,write_mode='r'):
	print "# Opening the following file in '"+write_mode+"' mode:",fn
	return open(fn,"w")

def build_structure(angles):
	geo = Geometry.geometry ("G")
	geo.phi     = angles[0][0]
	geo.psi_im1 = angles[0][1] # Ignored in the first instance
	geo.omega   = angles[0][2] # Ignored in the first instance
	
	structure = PeptideBuilder.initialize_res(geo)
	for i in range(1,len(angles)):
		geo = Geometry.geometry ("G")
		geo.phi     = angles[i][0] # current phi
		geo.psi_im1 = angles[i-1][1] # previous residue's psi
		geo.omega   = angles[i-1][2] # Ignored in the first instance
		structure = PeptideBuilder.add_residue(structure, geo)
	return structure